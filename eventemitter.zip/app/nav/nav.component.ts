import { Component, OnInit } from '@angular/core';
import { AppSettings } from '../app.config';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  navItems = AppSettings.APP_ROUTES;
  constructor() { }

  ngOnInit() {
  }

}

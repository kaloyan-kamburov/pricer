import { Component } from '@angular/core';
import { TestComponent } from './test/test.component';

@Component({
  selector: 'app-pricer',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  inputs: ['sendText']
})
export class AppComponent {
  name = 'aa';
  title = 'app works!';

  hobbies = '';   
}

import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';

export class AppSettings {
	public static APP_ROUTES = [
		{ path: '', component: HomeComponent, name: 'Home' },
  		{ path: 'about', component: AboutComponent, name: 'About' }
	]	
} 
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css'],
  inputs: ['name:myName'],
  outputs: ['itemInputEventEmitter'] 
})
export class TestComponent {
  name = '';
  text = '';

  itemInputEventEmitter = new EventEmitter<string>();

  sendText(text: string) {
    this.itemInputEventEmitter.emit(text);
  }

  constructor() { }


}

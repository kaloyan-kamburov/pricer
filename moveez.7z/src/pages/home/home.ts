import { Component } from '@angular/core';
import { NavController, ModalController, Platform } from 'ionic-angular';
import { AngularFireDatabase } from 'angularfire2/database';
import { FirebaseListObservable } from 'firebase/database';
import 'rxjs/add/operator/map';
import * as firebase from 'firebase';

@Component({
	selector: 'page-home',
	templateUrl: 'home.html'
})
export class HomePage {
	public movies: FirebaseListObservable<any[]>;
	public dbRef: any;

	constructor(public navCtrl: NavController,
		private db: AngularFireDatabase,
		private modalCtrl: ModalController,
		private platform: Platform) {

	}

	ionViewDidLoad() {
		this.platform.ready()
			.then(() => {
				this.db.list('/films').valueChanges().subscribe((movies) => {
					console.log(movies)
					this.movies = movies;

				})
			})
	}

	addRecord() {
		let modal = this.modalCtrl.create('Modals');
		modal.present();
	}

	editMovie(movie) {
		let params = { movie: movie, isEdited: true },
			modal = this.modalCtrl.create('Modals', params);

		modal.present();
	}

	deleteMovie(movie: any) {

		this.movies.remove(movie);
	}

}

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IonicPage, NavController, ViewController, NavParams } from 'ionic-angular';
import { AngularFireDatabase } from 'angularfire2/database';
import { FirebaseListObservable } from 'firebase/database';


/**
 * Generated class for the ModalsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({name: 'Modals'})
@Component({
	selector: 'page-modals',
	templateUrl: 'modals.html',
})
export class ModalsPage {
	public form: any;
	public movies: FirebaseListObservable<any[]>;
	public movieName: any;
	public movieGenres: any = [];
	public movieDuration: any = '';
	public movieSummary: any = '';
	public movieActors: any = [];
	public movieYear: any = '';
	public movieRating: any = '';
	public movieId: string = '';
	public isEditable: boolean = false;
	

	constructor(
		public navCtrl: NavController, 
		public params: NavParams,
		private _FB: FormBuilder,
		private _DB: AngularFireDatabase,
		public viewCtrl: ViewController
	) 
	{
		this.form = _FB.group({
			'summary': ['', Validators.minLength(10)],
			'year': ['', Validators.maxLength(4)],
			'name': ['', Validators.required],
			'duration': ['', Validators.required],
			'rating': ['', Validators.required],
			'genres': ['', Validators.required],
			'actors': ['', Validators.required]
		});

		this.movies = this._DB.list('/films');

		if (params.get('isEdited')) {
			let movie = params.get('movie'),
				k;
			
			this.movieName = movie.title;
			this.movieDuration = movie.duration;
			this.movieSummary = movie.summary;
			this.movieRating = movie.rating;
			this.movieYear = movie.year;
			this.movieId = movie.$key;	
			
			console.log(movie)

			for (k in movie.genres) {
				this.movieGenres.push(movie.genres[k].name)
			}

			for (k in movie.actors) {
				this.movieActors.push(movie.actors[k].name)
			}

			this.isEditable = true;
		}
	}

	saveMovie(val) {
		let title: string = this.form.controls["name"].value,
		summary: string = this.form.controls["summary"].value,
		rating: number	= this.form.controls["rating"].value,
		genres: any = this.form.controls["genres"].value,
		actors: any = this.form.controls["actors"].value,
		duration: string = this.form.controls["duration"].value,
		year: string = this.form.controls["year"].value,
		types: any = [],
		people: any = [],
		k: any,
		movieId: string;

		for (k in genres) {
			types.push({
				'name': genres[k]
			});
		}

		for (k in actors) {
			people.push({
				'name': actors[k]
			})
		}

		if (this.isEditable) {
			this.movies.update(this.movieId, {
				title: title,
				summary: summary,
				rating: rating,
				duration: duration,
				genres: types,
				actors: people,
				year: year
			})
			debugger;
		} else {
			this.movies.push({
				title: title,
				summary: summary,
				rating: rating,
				duration: duration,
				genres: types,
				actors: people,
				year: year
			})
		}

		this.closeModal();

	}

	closeModal() {
		this.viewCtrl.dismiss();
	}

	ionViewDidLoad() {
		// console.log('ionViewDidLoad ModalsPage');
	}

}

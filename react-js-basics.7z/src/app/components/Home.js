import React from "react";

export class Home extends React.Component {
    render() {
        return(
            <div>
                <p>In a new component</p>
            </div>
        );
    }
}
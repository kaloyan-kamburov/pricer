import { NgModule } from '@angular/core';
import { Routes, RouterModule} from '@angular/router';
import { AppSettings } from '../../app.settings';

@NgModule({
  imports: [
    RouterModule.forRoot(AppSettings.ROUTES)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }

import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { AngularFireAuth } from 'angularfire2/auth';

import {Observable} from "rxjs/Observable";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';


@Injectable()
export class AuthGuard implements CanActivate {

    constructor(
        private router: Router, 
        private firebaseAuth: AngularFireAuth,
        private apiService: ApiService
    ) { }

    canActivate() {

        return this.firebaseAuth.authState
            .take(1)
            .map(authState => !!authState)
            .do(auth => !auth ? this.router.navigate(['/login']) : true);

    }
}
import { Injectable } from '@angular/core';
import { AngularFireAuth } from 'angularfire2/auth';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs'

@Injectable()
export class ApiService {

    public userToken: String;

    constructor(private firebaseAuth: AngularFireAuth) {
    }

    login(formValue) {
        return Observable.fromPromise(this.firebaseAuth.auth.signInWithEmailAndPassword(formValue.email, formValue.password));
    }

    logout() {
        return Observable.fromPromise(this.firebaseAuth.auth.signOut());
    }

    registerUser(formValue) { 
        return Observable.fromPromise(this.firebaseAuth.auth.createUserWithEmailAndPassword(formValue.email, formValue.password));
    }
    


}
import { Injectable, Input, Output, EventEmitter } from '@angular/core';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs'
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import * as firebase from 'firebase';


@Injectable()
export class ApiService {
    
    public loggedInSrc = new BehaviorSubject<boolean>(false);
    public loggedIn = this.loggedInSrc.asObservable();
    public user;

    constructor(private firebaseAuth: AngularFireAuth, private db: AngularFireDatabase) {
        this.firebaseAuth.auth.onAuthStateChanged(user => {
            if (user) {
                this.user = this.firebaseAuth.auth.currentUser;
                this.changeLoggedState(true);
            } else {
                this.changeLoggedState(false);
            }
        });

    }

    login(formValue) {
        return Observable.fromPromise(this.firebaseAuth.auth.signInWithEmailAndPassword(formValue.email, formValue.password));
    }

    logout() {
        return Observable.fromPromise(this.firebaseAuth.auth.signOut());
    }

    registerUser(formValue) { 

        return Observable.fromPromise(this.firebaseAuth.auth.createUserWithEmailAndPassword(formValue.email, formValue.password)
            .then(() => {
                firebase.auth().onAuthStateChanged(user => {
                    if (user) {
                        user.updateProfile({
                            displayName: formValue.username,
                            photoURL: ''
                        })

                    }
                })

            })
            .catch(err => {})
        ); 
    }    

    changeLoggedState(state) {
        this.loggedInSrc.next(state);
    }

    getUser() {
        return this.user;
    } 

    sendMessage(user, value) {
        return Observable.fromPromise(this.db.list('messages').push('[ ' + user + ' ] ' + value));
    }

    // getMessages(msgCount, startIndex, endIndex, last) {
    getMessages() {
        return this.db.list('/messages', {
            query: {
                limitToLast: 10
            }
        });   


        // if (last) {
        //     return this.db.list('/messages', { 
        //        query: {
        //            limitToLast: msgCount
        //        }
        //     });            
        // } else {
        //     return this.db.list('/messages', {
        //         query: {
                    
        //             startAt: {
        //                 index: startIndex
        //             },
        //             endAt: endIndex
        //         }
        //     });   

        // }	
    }
    


}
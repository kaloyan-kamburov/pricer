import { Routes } from '@angular/router';

import { LoginComponent } from '../pages/login/login.component';
import { RegisterComponent } from '../pages/register/register.component';
import { ProfileComponent } from '../pages/profile/profile.component';
import { HomeComponent } from '../pages/home/home.component';


import { AuthGuard } from '../common/guards/auth.guard';


export class AppSettings {
    public static API_PATH = 'http://localhost:3000'
    public static SITE_PATH = 'http://localhost:4200'
    
    public static ROUTES: Routes = [
        {
            path: '',
            component: HomeComponent,
            data: {
                name: 'Home'
            }
        },
        { 
            path: 'login', 
            component: LoginComponent, 
            data: {
                name: 'Login',
                publicPage: true
            } 
        },
        { 
            path: 'register', 
            component: RegisterComponent, 
            data: {
                name: 'Register',
                publicPage: true
            } 
        },
        { 
            path: 'profile', 
            component: ProfileComponent, 
            data: {
                name: 'Profile',
                publicPage: false
            },
            canActivate: [AuthGuard]
        }
    ];

    public static fireBaseConfig = {
        apiKey: "AIzaSyALvpY0PyAFVYXfpk9SxPmnSnqljTMgkro",
        authDomain: "air4-7f1d0.firebaseapp.com",
        databaseURL: "https://air4-7f1d0.firebaseio.com",
        projectId: "air4-7f1d0",
        storageBucket: "",
        messagingSenderId: "493915217471"
    }
}
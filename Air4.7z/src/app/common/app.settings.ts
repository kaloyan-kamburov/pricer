import { Routes } from '@angular/router';

import { LoginComponent } from '../pages/login/login.component';
import { HomeComponent } from '../pages/home/home.component';


export class AppSettings {
    public static API_PATH = 'http://localhost:3000'
    public static SITE_PATH = 'http://localhost:4200'
    
    public static ROUTES: Routes = [
        {
            path: '',
            component: HomeComponent
        },
        { 
            path: 'login', 
            component: LoginComponent, 
            data: {
                name: 'Home',
                publicPage: true
            } 
        }
    ];

    public static fireBaseConfig = {
        apiKey: "AIzaSyALvpY0PyAFVYXfpk9SxPmnSnqljTMgkro",
        authDomain: "air4-7f1d0.firebaseapp.com",
        databaseURL: "https://air4-7f1d0.firebaseio.com",
        projectId: "air4-7f1d0",
        storageBucket: "",
        messagingSenderId: "493915217471"
    }
}
import { Component, OnInit } from '@angular/core';
import { AppSettings } from '../../common/app.settings';
import { ApiService } from '../../common/services/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
	isCollapsed = true;
	navRoutes;

	constructor(private appSettings: AppSettings, private apiService: ApiService, private router: Router) { 
		this.navRoutes = AppSettings.ROUTES;
	}

	logout() {
		this.apiService.logout().subscribe(data => {
			this.router.navigate(['/'])
		},
		err => {

		})
	}

	ngOnInit() {
	}

}

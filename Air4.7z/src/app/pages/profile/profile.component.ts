import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
	selector: 'app-profile',
	templateUrl: './profile.component.html',
	styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
	public user;
	public items;
	chatForm: FormGroup;

	constructor(private apiService: ApiService, private db: AngularFireDatabase,
		private fb: FormBuilder,) { }

	ngOnInit() {
		this.user = this.apiService.getUser();
		
		this.apiService.getMessages().subscribe(messages => {
			this.items = messages;
			// console.log(messages)
		},
		err => {

		});

		this.chatForm = this.fb.group({
			'message': [null, [Validators.required]]
		});
	}

	sendMessage() {
		this.apiService.sendMessage(this.user.displayName, this.chatForm.value.message).subscribe(data => {
			this.chatForm.reset();
			this.items = data;
		})
	}

}

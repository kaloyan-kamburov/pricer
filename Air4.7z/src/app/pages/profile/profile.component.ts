import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
	selector: 'app-profile',
	templateUrl: './profile.component.html',
	styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
	public user;
	public items;
	public chatForm: FormGroup;
	public loading: Boolean = true;

	constructor(private apiService: ApiService, private db: AngularFireDatabase,
		private fb: FormBuilder,) { }

	ngOnInit() {
		this.user = this.apiService.getUser();
		
		this.apiService.getMessages().subscribe(messages => {
			this.items = messages;
			this.loading = false;
		},
		err => {

		});

		this.chatForm = this.fb.group({
			'message': [null, [Validators.required]]
		});
	}

	sendMessage() {
		this.apiService.sendMessage(this.user.displayName, this.chatForm.value.message).subscribe(messages => {
			this.chatForm.reset();
			this.items = messages;
		})
	}

}

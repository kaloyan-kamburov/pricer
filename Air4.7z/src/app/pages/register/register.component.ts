import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { customValidators } from '../../common/services/form.customValidators';
import { ApiService } from '../../common/services/api.service';

@Component({
	selector: 'app-register',
	templateUrl: './register.component.html',
	styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
	registerForm: FormGroup;
	formSubmitted: Boolean = false;
	successfulRegistration: Boolean = false;

  	constructor(
		private fb: FormBuilder,
		private apiService: ApiService
  	) { }

	ngOnInit() {
		this.registerForm = this.fb.group({
			'username': [null, Validators.required],
			'email': [null, [Validators.required, Validators.email]],
			'password': [null, [Validators.required, Validators.minLength(6)]],
			'confirmPassword': [null, Validators.required]
		}, {
			validator: customValidators.MatchPassword
		});
	}

	register() {
		this.formSubmitted = true;
		this.apiService.registerUser(this.registerForm.value).subscribe(
			data => {
				this.successfulRegistration = true;
			},
			error => {
				console.log('error: ' + error);
			}
		)
	}

}

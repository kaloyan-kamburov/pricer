import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../../common/services/api.service';
import { Router } from '@angular/router';
import { AngularFireAuth } from 'angularfire2/auth';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
	loginForm: FormGroup;
 
  constructor(
    private fb: FormBuilder,
	private apiService: ApiService,
	private router: Router,
	private af: AngularFireAuth
  ) { }

  ngOnInit() {
	this.loginForm = this.fb.group({
		'email': [null, [Validators.required, Validators.email]],
		'password': [null, Validators.required]
	});
  }

  	login() {
    	this.apiService.login(this.loginForm.value).subscribe(
			data => {
				this.apiService.changeLoggedState(true);
				this.router.navigate(['/profile']);
			},
			error => {
				console.log('error: ' + error);
			}
		)
  	}

}

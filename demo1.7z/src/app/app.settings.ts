//routes
import { Injectable } from '@angular/core';
import { Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { MyAccountComponent } from './my-account/my-account.component';
import { UserService } from './shared/services/user.service';

@Injectable()
export class AppSettings {
    routes: Routes;

    constructor() {
        this.routes =[
            { 
                path: '', 
                component: HomeComponent, 
                data: {
                    name: 'Home'
                } 
            },
            { 
                path: 'my-account', 
                component: MyAccountComponent, 
                canActivate: [UserService],
                data: {
                    name: 'My account'
                } 
            }
        ]
    }
}
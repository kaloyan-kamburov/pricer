import { Injectable } from '@angular/core';

import {
    CanActivate,
    Router,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from '@angular/router';

import * as firebase from 'firebase';

@Injectable()
export class UserService implements CanActivate {
    userLogged: boolean = false;
    authUser: any;
    loggedUser: any;

    constructor(private router: Router) {

    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        let url: string = state.url;
        return this.verifyLogin(url); 
    }

    verifyLogin(user: string):boolean {
        if (this.userLogged) { return true; }

        this.router.navigate(['/login']);
        return false;
    }

    verifyUser() {
        // this.authUser = firebase.auth().currentUser;

        if (this.authUser) {
            this.loggedUser = this.authUser.email;
            this.userLogged = true;
            this.router.navigate(['/admin']);
        }
    }

    logout(): void {
        this.authUser = null;
        this.userLogged = false;
            this.router.navigate(['/user']);
    }

}
import { Component, OnInit } from '@angular/core';
import { AppSettings } from '../../../app.settings';
import { Routes } from '@angular/router';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent {
  public routes: Routes;

  constructor(private appSettings: AppSettings) {
    this.routes = this.appSettings.routes;
   }

  ngOnInit() {
    
  }

}

import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, ModalController, LoadingController, AlertController } from 'ionic-angular';
import { AngularFireDatabase } from 'angularfire2/database';

import { Content } from 'ionic-angular';

/**
 * Generated class for the MileagePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
	selector: 'page-expenes',
	templateUrl: 'expenes.html',
})
export class ExpensesPage {
	@ViewChild(Content) public content: Content;

	public expensesRecords = [];
	public allexpensesRecords = [];
	public expandedRecord: any;
	public loading;
	public alert;
	public noRecords: boolean = true;
	public allRecordsVisible: boolean = false;

	constructor(
		public loadingCtrl: LoadingController,
		public alertCtrl: AlertController,
		public navCtrl: NavController,
		public navParams: NavParams,
		private db: AngularFireDatabase,
		private modalCtrl: ModalController
	) {
	}

	ionViewDidEnter() {
		this.allRecordsVisible = false;
		
		if (this.expensesRecords.length > 0) {
			this.expensesRecords = this.expensesRecords.slice(-6);
		}
	}

	showLoading() {
		this.loading = this.loadingCtrl.create({
			spinner: 'crescent',
			content: 'Зареждане...'
		});

		this.loading.present();
	}

	hideLoading() {
		this.loading.dismiss();
	}

	ionViewDidLoad() {
		
		this.allRecordsVisible = this.navParams.get('allRecordsVisible');

		this.showLoading();


		this.db.list('expenses', ref => ref.limitToLast(1)).valueChanges().subscribe(records => {

			this.allRecordsVisible = records.length < 5;
			
			if (records && records.length) {
				// this.allexpensesRecords = records;
				this.expensesRecords = records;
				this.hideLoading();
				this.noRecords = false;

				if (this.allRecordsVisible) {
					this.showAllRecords();
				}
			} else {
				setTimeout( () => {
					this.allRecordsVisible = false;
					this.noRecords = true;
					this.expensesRecords = [];
					this.hideLoading();
				}, 1000);
			}
		});

	}

	showAllRecords() {
		
		this.showLoading();

		this.db.list('expenses').valueChanges().subscribe(records => {
			this.expensesRecords = records;
			this.allRecordsVisible = true;
			this.hideLoading();
		})

		setTimeout(() => {
			this.content.scrollToBottom();
		}, 1);
	}

	isRecordOpen(record) {
		return this.expandedRecord === record;
	}

	toggleRecordDetails(record) {
		if (this.isRecordOpen(record)) {
			this.expandedRecord = null;
		} else {
			this.expandedRecord = record;
		}
	}

	addRecord() {
		let params = {
			editMode: false
		},
		modal = this.modalCtrl.create('ModalExpenses', params);
		modal.present();
	}

	editRecord(record) {
		let params = {
			editMode: true,
			record: record,
			allRecordsVisible: this.allRecordsVisible
		},
		modal = this.modalCtrl.create('ModalExpenses', params);
		modal.present();
	}

	deleteRecord(record) {
		this.alert = this.alertCtrl.create({
			title: 'Изтриване на запис',
			message: 'Искате ли да изтриете този запис?',
			buttons: [
				{
					text: 'Отказ',
					role: 'cancel'
				},
				{
					text: 'Изтрий',
					handler: () => {						
						this.db.list('expenses').remove(record.key);

						if (this.allRecordsVisible) {
							this.showAllRecords();
						}
					}
				}
			]
		});

		this.alert.present();
	}

}

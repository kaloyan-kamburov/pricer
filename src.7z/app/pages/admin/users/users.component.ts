import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../common/api.service'; 

@Component({
	selector: 'app-users',
	templateUrl: './users.component.html',
	styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
	users: any;

	constructor(private apiService: ApiService) { }

	ngOnInit() {
		if (this.apiService.isAdminLogged) {
			this.apiService.getAllUsers().subscribe(users => {
				this.users = users;
			});

		}
	}

}

import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { ApiService } from './api.service';
import { ActivatedRouteSnapshot } from '@angular/router'

@Injectable()
export class AdminGuard implements CanActivate {

    constructor(private router: Router, public apiService: ApiService) {}
    
    public canActivate(route: ActivatedRouteSnapshot) {
        
        // if (this.apiService.checkAdminLogged()) {
        //     return true;
        // }
        // this.router.navigate(['/']); 
        // return false; 
        
        
        if (JSON.parse(localStorage.getItem('user')).isAdmin) {
            return true;
        }
        this.router.navigate(['/']); 
        return false; 

    }

}
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppRoutingModule } from './common/app.routing.module';

import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';
import { ProfileComponent } from './pages/profile//profile.component';

import { ApiService } from './common/api.service';
import { AuthGuard } from './common/auth.guard';
import { NavigationComponent } from './partials/navigation/navigation.component';
import { RegisterComponent } from './pages/register/register.component';

import { NgbModule, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProfileComponent,
    NavigationComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule,
    NgbModule.forRoot(),
    BrowserAnimationsModule
  ],
  providers: [ApiService, AuthGuard, NgbModalRef],
  bootstrap: [AppComponent]
})
export class AppModule { }

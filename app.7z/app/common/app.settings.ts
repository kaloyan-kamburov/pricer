//routes
import { Routes } from '@angular/router';

import { HomeComponent } from '../pages/home/home.component';
import { ProfileComponent } from '../pages/profile/profile.component';
import { RegisterComponent } from '../pages/register/register.component';
import { ErrorComponent } from '../pages/error/error.component';
import { AdminComponent } from '../pages/admin/admin.component';
import { UsersComponent } from '../pages/admin/users/users.component';

import { AuthGuard } from '../common/auth.guard';
import { AdminGuard } from '../common/admin.guard';

export class AppSettings {
    public static API_PATH = 'http://localhost:3000'
    public static SITE_PATH = 'http://localhost:4200'
    
    public static ROUTES: Routes = [
        { 
            path: '', 
            component: HomeComponent, 
            data: {
                name: 'Home',
                publicPage: true
            } 
        },
        { 
            path: 'profile', 
            component: ProfileComponent, 
            canActivate: [AuthGuard]
        },
        { 
            path: 'register', 
            component: RegisterComponent
        },
        { 
            path: 'error', 
            component: ErrorComponent,
        },
        { 
            path: 'admin', 
            component: AdminComponent, 
            canActivate: [AdminGuard],
            data: {
                roles: ['admin']
            },
            children: [
                { path: 'users', component: UsersComponent }
            ]
        }
    ]
}
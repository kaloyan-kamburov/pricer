import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { ApiService } from './api.service';

@Injectable()
export class AdminGuard implements CanActivate {

    constructor(private router: Router, private apiService: ApiService) {}

    public canActivate() {
        debugger;
        if (this.apiService.isAdminLogged) {
            return true;
        }
        this.router.navigate(['/']);
        return false;

    }

}
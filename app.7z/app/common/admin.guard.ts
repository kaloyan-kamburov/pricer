import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { ApiService } from './api.service';
import { ActivatedRouteSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable()
export class AdminGuard implements CanActivate {

    constructor(private router: Router, public apiService: ApiService) {}

    public isAdminAuthenticated():Observable<boolean> {
        let isAuth = new Observable<boolean>(observer => {
            if (this.apiService.loggedIn()) {
                this.apiService.getProfile().subscribe(profile => {

                    if (profile.user.isAdmin) {
                        observer.next(true);
                    } else {
                        this.router.navigate(['/']);
                        observer.next(false);
                    }

                    observer.complete();
                },
                err => {
                    console.log(err);
                });

            } else {
                this.router.navigate(['/']);
                observer.next(false);
            }
        });

        return isAuth;
    }
    
    public canActivate(route: ActivatedRouteSnapshot) {
        
        return this.isAdminAuthenticated(); 

    }

}
import { Injectable } from '@angular/core';

import {
    CanActivate,
    Router,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from '@angular/router';

import * as firebase from 'firebase';

@Injectable()
export class UserService implements CanActivate {
    userLogged: boolean = false;
    authUser: any;
    loggedUser: string;

    constructor(private router: Router) {
        firebase.initializeApp({
            apiKey: "AIzaSyDew6Se56sIhtCnnI774lCC3SpkZe_CnUc",
            authDomain: "test-bc5bf.firebaseapp.com",
            databaseURL: "https://test-bc5bf.firebaseio.com",
            projectId: "test-bc5bf",
            storageBucket: "test-bc5bf.appspot.com",
            messagingSenderId: "331670659940"
        });
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        let url: string = state.url;
        return this.verifyLogin(url); 
    }

    verifyLogin(user: string):boolean {
        if (this.userLogged) { return true; }

        this.router.navigate(['/login']);
        return false;
    }

    verifyUser() {
        this.authUser = firebase.auth().currentUser;

        if (this.authUser) {
            this.loggedUser = this.authUser.email;
            this.userLogged = true;
            this.router.navigate(['/my-account']);
        }
    }

    login(email: string, password: string) {
        firebase.auth().signInWithEmailAndPassword(email, password).catch(error => {
           console.log(`ERROR: ${error}`); 
        });
    }

    logout(): void {
        this.authUser = null;
        this.userLogged = false;
            this.router.navigate(['/user']);
    }

}
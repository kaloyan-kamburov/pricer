import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserService } from '../shared/services/user.service';
import { AppSettings } from '../app.settings';

@NgModule({
    imports: [
        RouterModule.forRoot(AppSettings.ROUTES)
    ],
    exports: [
        RouterModule
    ],
    providers: [UserService],
    declarations: []
})
export class AppRoutingModule { }
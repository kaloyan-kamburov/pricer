import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/services/user.service';
import * as firebase from 'firebase';

@Component({
	selector: 'app-login',
	templateUrl: './login.component.html',
	styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
	userCredentials: any = {};

	constructor(private userService: UserService) { }

	ngOnInit() {
	}
	
	login() {
		this.userService.login(this.userCredentials.email, this.userCredentials.password);
		this.userService.verifyUser();
	}
}

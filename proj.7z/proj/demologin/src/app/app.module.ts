import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';

import { ApiService } from './shared/services/api.service';
import { HomeComponent } from './home/home.component';
import { MyAccountComponent } from './my-account/my-account.component';

import { AppRoutingModule } from './shared/app.routing.module';
import { NavComponent } from './shared/components/nav/nav.component';


import { AppSettings } from './app.settings';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    MyAccountComponent,
    NavComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule
  ],
  providers: [ApiService, AppSettings],
  bootstrap: [AppComponent]
})
export class AppModule { }

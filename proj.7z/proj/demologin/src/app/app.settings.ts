//routes
import { Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { MyAccountComponent } from './my-account/my-account.component';
import { LoginComponent } from './login/login.component';
import { UserService } from './shared/services/user.service';

export class AppSettings {
    
    public static ROUTES: Routes = [
        { 
            path: '', 
            component: HomeComponent, 
            data: {
                name: 'Home',
                publicPage: true
            } 
        },
        { 
            path: 'login', 
            component: LoginComponent, 
            data: {
                name: 'Login',
                publicPage: true
            } 
        },
        { 
            path: 'my-account', 
            component: MyAccountComponent, 
            canActivate: [UserService],
            data: {
                name: 'My Account',
                publicPage: false
            } 
        }
    ]
}
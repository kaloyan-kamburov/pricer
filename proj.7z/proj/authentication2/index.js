var express = require('express'),
    passport = require('passport'),
    bodyParser = require('body-parser'),
    cors = require('cors'),
    router = express.Router(),
    app = express();

app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.use(passport.initialize());
app.use(router);
app.use(cors());
require('./passport.js')(passport);
require('./routes/home.js')(app, passport);

var port = process.env.PORT || 5858;


var server = app.listen(port, function() {
  console.log('Listening on port %d', server.address().port);
});

app.listen(port);
(function() {
  'use strict';
  angular
    .module('app')
    .factory('tokenInjector', [function() {
      var service = {};
      
       service.fetch = function() {
        var token = localStorage['token'];
        return $http
        .post('Page on localhost:3000', {}, {
          headers: {
            Authorization: token
          }
        })
        .then(function() {
          alert('Fetch resource successful');
        }, function() {
          alert('Can not fetch resource');
        });

       }

       return service;

     
    }])


})();
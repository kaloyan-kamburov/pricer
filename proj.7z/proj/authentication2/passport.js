var LocalStrategy = require('passport-local');

module.exports = function(passport) {
    var user = {
        id: 1,
        username: 'john',
        email: 'john@john.com'
    }

    passport.use('signin', new LocalStrategy({passReqToCallback: true}, 
        function(req, username, password, done) {        
            if (username === 'john' && password === '123') {
                return done(null, user)
            }

            return done(new Error('invalid username'));
        }
    ));
    
}
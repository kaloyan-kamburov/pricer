import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ModalFuelPage } from './modal-fuel';

@NgModule({
  declarations: [
    ModalFuelPage,
  ],
  imports: [
    IonicPageModule.forChild(ModalFuelPage),
  ],
})
export class ModalFuelPageModule {}

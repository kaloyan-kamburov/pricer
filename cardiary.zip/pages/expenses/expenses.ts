import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, ModalController, LoadingController, AlertController } from 'ionic-angular';
import { AngularFireDatabase } from 'angularfire2/database';

import { Content } from 'ionic-angular';

/**
 * Generated class for the MileagePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
	selector: 'page-mileage',
	templateUrl: 'expenses.html',
})
export class ExpensesPage {
	@ViewChild(Content) public content: Content;

	public expensesRecords = [];
	public allExpensesRecords = [];
	public expandedRecord: any;
	public loading;
	public alert;
	public noRecords: boolean = true;
	public allRecordsVisible: boolean = false;

	constructor(
		public loadingCtrl: LoadingController,
		public alertCtrl: AlertController,
		public navCtrl: NavController,
		public navParams: NavParams,
		private db: AngularFireDatabase,
		private modalCtrl: ModalController
	) {
	}

	ionViewDidEnter() {
		this.allRecordsVisible = false;

		if (this.expensesRecords.length > 0) {
			this.expensesRecords = this.expensesRecords.slice(-6);
		}
	}

	ionViewDidLoad() {

		this.allRecordsVisible = this.navParams.get('allRecordsVisible');

		this.loading = this.loadingCtrl.create({
			spinner: 'crescent',
			content: 'Зареждане...'
		});

		this.loading.present();

		this.db.list('expenses').valueChanges().subscribe((records) => {
			if (records && records.length) {
				this.allExpensesRecords = records;
				this.expensesRecords = records.slice(-6);
				this.loading.dismiss();
				this.noRecords = false;

				if (this.allRecordsVisible) {
					this.showAllRecords();
				}
			} else {
				setTimeout(() => {
					this.allRecordsVisible = false;
					this.noRecords = true;
					this.loading.dismiss();
				}, 1000);
			}
		});

	}

	showAllRecords() {
		this.expensesRecords = this.allExpensesRecords;
		this.allRecordsVisible = true;

		setTimeout(() => {
			this.content.scrollToBottom();
		}, 1);
	}

	isRecordOpen(record) {
		return this.expandedRecord === record;
	}

	toggleRecordDetails(record) {
		if (this.isRecordOpen(record)) {
			this.expandedRecord = null;
		} else {
			this.expandedRecord = record;
		}
	}

	addRecord() {
		let params = {
			editMode: false
		},
			modal = this.modalCtrl.create('ModalExpenses', params);
		modal.present();
	}

	editRecord(record) {
		let params = {
			editMode: true,
			record: record,
			allRecordsVisible: this.allRecordsVisible
		},
			modal = this.modalCtrl.create('ModalExpenses', params);
		modal.present();
	}

	deleteRecord(record) {
		this.alert = this.alertCtrl.create({
			title: 'Изтриване на запис',
			message: 'Искате ли да изтриете този запис?',
			buttons: [
				{
					text: 'Отказ',
					role: 'cancel'
				},
				{
					text: 'Изтрий',
					handler: () => {
						this.db.list('expenses').remove(record.key);

						if (this.allRecordsVisible) {
							this.showAllRecords();
						}
					}
				}
			]
		});

		this.alert.present();
	}

}

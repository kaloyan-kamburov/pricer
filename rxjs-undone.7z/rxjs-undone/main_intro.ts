// import { Observable, Observer } from 'rxjs';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/filter';

let numbers = [1, 5, 10];

let source = Observable.create(observer => {
    ///for loop
    // for (let n of numbers) {

    //     // if (n === 5) {
    //     //     observer.error('something went wrong');
    //     // }

    //     observer.next(n)
    // }

    // observer.complete();
    ///end for loop


    ///with timeout
    let index = 0;
    let produceValue = () => {
        observer.next(numbers[index++]);

        if (index < numbers.length) {
            setTimeout(produceValue, 250)
        } else {
            observer.complete();
        }
    }

    produceValue();
    ///end with timeout

}).map(n => n*2)
  .filter(n=> n > 4);

source.subscribe(
    value => console.log(`value: ${value}`),
    e => console.log(e),
    () => console.log('complete')
);



// let source = Observable.from(numbers);

// source.subscribe(
//     value => console.log(value),
//     e => console.log(e),
//     () => console.log('error')
// );




// class MyObserver implements Observer<number> {
    
//     next(value) {
//         console.log(value);
//     }

//     error(e) {
//         console.log(e);
//     }

//     complete() {
//         console.log('complete');
//     }
// }

// source.subscribe(new MyObserver());
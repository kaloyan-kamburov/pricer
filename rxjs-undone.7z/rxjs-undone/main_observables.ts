import { Observable } from 'rxjs';

///mouse events
// let circle = document.getElementById('circle');
// let source = Observable.fromEvent(document, 'mousemove')
//                        .map((e : MouseEvent) => {
//                            return {
//                                x: e.clientX,
//                                y: e.clientY
//                            }
//                        })
//                        .delay(3000);

// function onNext(value) {
//     console.log(value);
//     circle.style.left = value.x + 'px';
//     circle.style.top = value.y + 'px';
// }

// source.subscribe(
//     onNext,
//     e => console.log(e),
//     () => console.log('complete')
// );
///end mouse events

///with xmlhttprequest
// let output = document.getElementById('otuput');
// let button = document.getElementById('button');

// let click = Observable.fromEvent(button, 'click');

// function load(url: string) {
//     let xhr = new XMLHttpRequest();

//     xhr.addEventListener('load', () => {
//         let movies = JSON.parse(xhr.responseText);
//         movies.forEach(m => {
//             let div = document.createElement('div');
//             div.innerText = m.title;
//             output.appendChild(div);
//         });
//     });

//     xhr.open('GET', url);
//     xhr.send();
// }


// click.subscribe(
//     e => load("movies.json"),
//     e => console.log(e),
//     () => console.log('complete')
// );
///end xmlhttprequest


///xmlhttprequest with flatmap
// let output = document.getElementById('output');
// let button = document.getElementById('button');

// let click = Observable.fromEvent(button, 'click');

// function load(url: string) {
//     return Observable.create(observer => {
//         let xhr = new XMLHttpRequest();

//         xhr.addEventListener('load', () => {
//             let data = JSON.parse(xhr.responseText);

//             observer.next(data);
//             observer.complete();
//         });

//         xhr.open('GET', url);
//         xhr.send();
//     });
// }

// function renderMovies(movies) {

//     movies.forEach(m => {
//         let div = document.createElement('div');
//         div.innerText = m.title;
//         output.appendChild(div);
//     });
// }

// click.flatMap(e => load("movies.json"))
//     .subscribe(
//         renderMovies,
//         e => console.log(e),
//         () => console.log('complete')
//     );

///end xmlhttprequest with flatmap

///xmlhttprequest with retry
// let output = document.getElementById('output');
// let button = document.getElementById('button');

// let click = Observable.fromEvent(button, 'click');

// function load(url: string) {
//     return Observable.create(observer => {
//         let xhr = new XMLHttpRequest();

//         xhr.addEventListener('load', () => {
//             if (xhr.status === 200) {
//                 let data = JSON.parse(xhr.responseText);

//                 observer.next(data);
//                 observer.complete();

//             } else {
//                 observer.error(xhr.statusText);
//             }
//         });

//         xhr.open('GET', url);
//         xhr.send();
//     }).retryWhen(retryStrategy({attempts: 3, delay: 1500}));
// }

// function retryStrategy({ attempts = 4, delay = 1000}) {
//     return function(errors) {
//         return errors
//                 .scan((accumulator, value) => {
//                     console.log(`accumulator: ${accumulator} value: ${value}`);
//                     return accumulator + 1;
//                 }, 0)
//                 .takeWhile(accumulator => accumulator < attempts)
//                 .delay(delay);
//     }
// }

// function renderMovies(movies) {

//     movies.forEach(m => {
//         let div = document.createElement('div');
//         div.innerText = m.title;
//         output.appendChild(div);
//     });
// }

// click.flatMap(e => load("moviess.json"))
//     .subscribe(
//         renderMovies,
//         e => console.log(`error: ${e}`),
//         () => console.log('complete')
//     );
///end xmlhttprequest with retry


///xmlhttprequest with promises
let output = document.getElementById('output');
let button = document.getElementById('button');

let click = Observable.fromEvent(button, 'click');

function load(url: string) {
    return Observable.create(observer => {
        let xhr = new XMLHttpRequest();

        xhr.addEventListener('load', () => {
            if (xhr.status === 200) {
                let data = JSON.parse(xhr.responseText);

                observer.next(data);
                observer.complete();

            } else {
                observer.error(xhr.statusText);
            }
        });

        xhr.open('GET', url);
        xhr.send();
    }).retryWhen(retryStrategy({attempts: 3, delay: 1500}));
}

function loadWithFetch(url: string) {
    return Observable.defer(() => {
        return Observable.fromPromise(fetch(url).then(r => r.json()));
    });
}

function retryStrategy({ attempts = 4, delay = 1000}) {
    return function(errors) {
        return errors
                .scan((accumulator, value) => {
                    console.log(`accumulator: ${accumulator} value: ${value}`);
                    return accumulator + 1;
                }, 0)
                .takeWhile(accumulator => accumulator < attempts)
                .delay(delay);
    }
}

function renderMovies(movies) {

    movies.forEach(m => {
        let div = document.createElement('div');
        div.innerText = m.title;
        output.appendChild(div);
    });
}

click.flatMap(e => loadWithFetch("movies.json"))
    .subscribe(
        renderMovies,
        e => console.log(`error: ${e}`),
        () => console.log('complete')
    );
///end xmlhttprequest with promises
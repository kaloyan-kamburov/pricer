import { Observable } from 'rxjs';
import { load, loadWithFetch } from './loader';

///Observable.onErrorResumeNext - swallow errors and continue without throwing
///next lines allow us if in the merge() method we have an error that has error and then return cached data for example...

///////experiment
// let source = Observable.merge(
//     Observable.of(1),
//     Observable.from([2, 3, 4]),
//     Observable.throw(new Error('stop')),
//     Observable.of(5)
// ).catch(e => {
//     console.log(`caught: ${e}`)
//     return Observable.of(10);
// })

// source.subscribe(
//     value => console.log(`value: ${value}`),
//     error => console.log(`error: ${error}`),
//     () => console.log(`complete`)
// )
//////end experiment


// //////revising retryWhen strategy
// let output = document.getElementById('output');
// let button = document.getElementById('button');

// let click = Observable.fromEvent(button, 'click');



// function renderMovies(movies) { 

//     movies.forEach(m => {
//         let div = document.createElement('div');
//         div.innerText = m.title;
//         output.appendChild(div);
//     });
// }

// loadWithFetch("movies.json").subscribe(renderMovies,
//     e => console.log(`error: ${e}`),
//     () => console.log());

// click.flatMap(e => loadWithFetch("moviess.json"))
//     .subscribe(
//         renderMovies,
//         e => console.log(`error: ${e}`),
//         () => console.log('complete')
//     );
// //////end revising retryWhen strategy




//////unsubscribe 
let output = document.getElementById('output');
let button = document.getElementById('button');

let click = Observable.fromEvent(button, 'click');



function renderMovies(movies) { 

    movies.forEach(m => {
        let div = document.createElement('div');
        div.innerText = m.title;
        output.appendChild(div);
    });
}

let subscription = load("movies.json").subscribe(renderMovies,
    e => console.log(`error: ${e}`),
    () => console.log());

subscription.unsubscribe();

click.flatMap(e => loadWithFetch("movies.json"))
    .subscribe(
        renderMovies,
        e => console.log(`error: ${e}`),
        () => console.log('complete')
    );
//////end unsubscribe
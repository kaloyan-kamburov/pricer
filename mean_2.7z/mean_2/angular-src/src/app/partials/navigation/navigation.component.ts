import { Component, OnInit, ComponentRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ApiService } from '../../common/api.service';
import { Router } from '@angular/router';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {

  	username: String;
	password: String;
	errorLogged: boolean = false;
	errorMsg: String;

	constructor(
		private router: Router, 
		private apiService: ApiService, 
		private modalService: NgbModal) { }

	ngOnInit() {
	}

	login(callback) {
		this.apiService.login(this.username, this.password).subscribe(data => {
			if (data.success) {
				this.apiService.storeUserData(data.token, data.user);
				callback();
				this.router.navigate(['/profile']);
			} else {
				this.errorLogged = true;
				this.errorMsg = data.msg;
			}
		})
	}

	logout() {
		this.apiService.logout();
		this.router.navigate(['/']);
	}

	open(content) {
		this.errorLogged = false;
		this.username = '';
		this.password = '';
		this.modalService.open(content);
	}

}

import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../../../common/services/api.service';

@Component({
	selector: 'app-edit-user',
	templateUrl: './edit-user.component.html',
	styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
	user: any;

	name: string;
	email: string;
	password: String;

	editUserForm: FormGroup;
	
	bla: any;

	constructor(
		private router: Router, 
		private activatedRoute: ActivatedRoute, 
		private apiService: ApiService,
		private fb: FormBuilder) { 



			this.editUserForm = this.fb.group({
				'name': [null, Validators.required],
				'email': [null, [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]],
				'password': [null, Validators.required]
			});


		}

	ngOnInit() {
		this.activatedRoute.params.subscribe(
			(params: Params) => {
				let id = params['id'];

				this.apiService.getUser(id).subscribe(
					(user) => {
						this.user = user;

						Object.keys(user).forEach(key => {
							if (this.editUserForm.controls[key]) {
								this.editUserForm.controls[key].setValue(user[key]);
							}
						});

					},
					e => console.log(e),
					() => {}
				)
			},
			e => console.log(e),
			() => {

			}
		);
	}

	editUser() {
		alert('dsa')
	}
}

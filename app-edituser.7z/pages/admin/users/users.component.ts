import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../common/services/api.service'; 

@Component({
	selector: 'app-users',
	templateUrl: './users.component.html',
	styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
	users: any;

	constructor(private apiService: ApiService) { }

	ngOnInit() { 
		this.apiService.checkAdminLogged().subscribe(isAdminLogged => {
			if (isAdminLogged) {
				this.apiService.getAllUsers().subscribe(users => {
					this.users = users;

					this.users.forEach( (element, index) => {
						if (element.isAdmin) {
							this.users.splice(index, 1);
						}
					});
				});
			}
		},
		error => (e) => console.log(e),
		() => {});
	}

}

import { Component, OnInit } from '@angular/core';
import { User } from '../_models/';
import { UserService } from '../_services/';

@Component({
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  users: User[] = [];

  constructor(private UserService: UserService) { }

  ngOnInit() {
    this.UserService.getUsers()
      .subscribe((users) => {
        this.users = users;
      },
      (err) => {
        console.log('ERRORRRRR');
      })
  }

}

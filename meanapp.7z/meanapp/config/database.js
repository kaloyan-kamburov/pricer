module.exports = {
    database: 'mongodb://localhost:27017/meanauth',
    secret: 'yoursecret'
}
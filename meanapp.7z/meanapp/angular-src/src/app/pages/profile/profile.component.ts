import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
	selector: 'app-profile',
	templateUrl: './profile.component.html',
	styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
	user: Object;
	userName: Object;

	editUserForm: FormGroup;

	constructor(private apiService: ApiService, private fb: FormBuilder	) { }

	ngOnInit() {
		this.apiService.getProfile().subscribe(profile => {
			this.user = profile.user;
			this.userName = profile.user.username;

			this.editUserForm.controls['name'].setValue(profile.user.name);
			this.editUserForm.controls['email'].setValue(profile.user.email);
		});
		
						
		this.editUserForm = this.fb.group({
			'name': [null, Validators.required],
			'email': [null, Validators.compose([Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]) ]
		});
		
	}



}

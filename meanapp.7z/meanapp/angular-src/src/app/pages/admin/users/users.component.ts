import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../common/services/api.service'; 

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
	selector: 'app-users',
	templateUrl: './users.component.html',
	styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
	users: any;

	deleteId: any;

	constructor(
		private apiService: ApiService,	
		private modalService: NgbModal) { }

	loadUsers() {
		this.apiService.checkAdminLogged().subscribe(isAdminLogged => {
			if (isAdminLogged) {
				this.apiService.getAllUsers().subscribe(users => {
					this.users = users;

					this.users.forEach( (element, index) => {
						if (element.isAdmin) {
							this.users.splice(index, 1);
						}
					});
				});
			}
		},
		error => (e) => console.log(e),
		() => {});
	}

	ngOnInit() { 
		this.loadUsers();
	}

	openDeleteModal(content, id) {
		this.modalService.open(content);

		this.deleteId = id;
	}

	deleteUser(id, callback) {
		this.apiService.deleteUser(id).subscribe(
			res => {
				this.loadUsers();
				callback()
			},
			e => console.log(e),
			() => {}
		);
	}

}

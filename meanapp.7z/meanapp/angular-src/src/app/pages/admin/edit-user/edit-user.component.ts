import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../../../common/services/api.service';
import { Observable } from 'rxjs';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
	selector: 'app-edit-user',
	templateUrl: './edit-user.component.html',
	styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
	user: any;

	name: string;
	email: string;
	password: String;
	userId: String;

	editUserForm: FormGroup;
	changePasswordForm: FormGroup;
	
	bla: any;

	userDataChanged: boolean = false;

	constructor(
		private router: Router, 
		private activatedRoute: ActivatedRoute, 
		private apiService: ApiService,
		private fb: FormBuilder,	
		private modalService: NgbModal) {}

	ngOnInit() { 		
		this.editUserForm = this.fb.group({
			'name': [null, Validators.required],
			'email': [null, Validators.compose([Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]) ]
		});

		 		
		this.changePasswordForm = this.fb.group({
			'password1': [null, Validators.compose([Validators.required, Validators.minLength(6)]) ],
			'password2': [null, Validators.compose([Validators.required, Validators.minLength(6)]) ],
		});

		this.activatedRoute.params.subscribe(
			(params: Params) => {
				this.userId = params['id'];

				this.apiService.getUser(this.userId).subscribe(
					(user) => {
						this.user = {
							name: user.name,
							email: user.email
						}

						Object.keys(user).forEach(key => {
							if (this.editUserForm.controls[key]) {
								this.editUserForm.controls[key].setValue(user[key]);
							}
						});

					},
					e => console.log(e),
					() => {}
				)
			},
			e => console.log(e),
			() => {

			}
		);
	}

	openPromptEditModal(content, form) {
		this.modalService.open(content);
	}

	compareChanges(value, key) {
		if (value !== this.user[key]) {
			this.userDataChanged = true;
		} else {
			this.userDataChanged = false;
		}
	}

	saveChanges(formValue, callback) {
		if (this.editUserForm.valid) {
			
			this.apiService.updateUser(this.userId, formValue).subscribe(
				res => callback(),
				e => console.log(e),
				() => {}
			);
		}
	}

	openChangePasswordModal(content, callback) {
		this.modalService.open(content);
	}

	checkPasswords() {
		if (this.changePasswordForm.controls['password1'].value === this.changePasswordForm.controls['password2'].value) {
			return true;
		}
		return false;
	}

	sumbitChangePassword(callback) {
		if (this.changePasswordForm.valid) {
			this.apiService.changePassword(this.userId, this.changePasswordForm.controls['password1'].value).subscribe(
				res => callback(),
				e => console.log(e),
				() => {}
			)
		}
	}
}

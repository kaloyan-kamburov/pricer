import { Component, OnInit, trigger, state, style, animate, transition, keyframes } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../../common/services/api.service';
import { Router } from '@angular/router';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@Component({
	selector: 'app-navigation',
	templateUrl: './navigation.component.html',
	styleUrls: ['./navigation.component.css'],
	animations: [

		trigger('navbarSlide', [
			state('slideUp', style({
				maxHeight: '0'
			})),
			state('slideDown', style({
				maxHeight: '300px'
			})),
			transition('slideUp => slideDown', animate('100ms linear')),
			transition('slideDown => slideUp', animate('100ms linear'))
		])

	]
})
export class NavigationComponent implements OnInit {

  	username: String;
	password: String;
	errorLogged: boolean = false;
	errorMsg: String;
	state: String = 'slideUp';
	isAdmin: Boolean = false;

	complexForm: FormGroup;

	constructor(
		private router: Router, 
		private apiService: ApiService, 
		private modalService: NgbModal,
		private fb: FormBuilder) { 

	}

	ngOnInit() {		
		this.complexForm = this.fb.group({
			'username': [null, Validators.required],
			'password': ''
		});
		this.apiService.checkAdminLogged().subscribe(
			res => {
				this.isAdmin = res;
			},
			e => console.log(e),
			() => {}
		);
	}

	login(value: any, callback) {
		this.apiService.login(value.username, value.password).subscribe(
			data => {
				if (data.success) {
					this.apiService.storeUserData(data.token, data.user);
					callback();
					this.isAdmin = data.user.isAdmin;

					if (data.user.isAdmin) {
						this.apiService.isAdminLogged = true;
						this.router.navigate(['/admin']);
					} else {
						this.router.navigate(['/profile']);
					}
					
				} else {
					this.errorLogged = true;
					this.errorMsg = data.msg;
				}
			},
			err => {
				this.errorLogged = true;
				this.errorMsg = 'Server is down! Please try again later!';
				this.complexForm.reset();
			}
		);
	}

	logout() {
		this.apiService.logout();
		this.isAdmin = false;
		this.router.navigate(['/']);
	}

	openLoginModal(content) {
		this.errorLogged = false;
		this.complexForm.reset();
		this.modalService.open(content);
	}

	toggleNav() {
		this.state = (this.state === 'slideUp' ? 'slideDown': 'slideUp');
	}

	// toggleNav(el) {
	// 	if (!this.navbarShow) {
	// 		this.renderer.setStyle(el, 'display', 'block');
	// 		this.renderer.setStyle(el, 'height', '100px');
	// 	} else {
	// 		this.renderer.setStyle(el, 'display', 'none');
	// 		this.renderer.setStyle(el, 'height', '0');
	// 	}
	// 	this.navbarShow = !this.navbarShow;
	// }

}

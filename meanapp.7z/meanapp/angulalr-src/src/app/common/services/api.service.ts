import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import { AppSettings } from '../app.settings';
import { tokenNotExpired } from 'angular2-jwt';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable()
export class ApiService {
	authToken: any;
	user: any;
	isAdminLogged: Boolean = false;
	constructor(private http: Http, private router: Router) { }

	checkAdminLogged() {
		let obs = Observable.create(observer => {
			this.getProfile().subscribe(profile => {
				observer.next(profile.user.isAdmin);
				observer.complete(profile.user.isAdmin);
			});	
		});		
		
		return obs;
	}

	login(username, password) {
		let headers = new Headers();
		headers.append('Content-Type', 'application/json');
		return this.http.post(AppSettings.API_PATH + '/users/authenticate', {
			username: username,
			password: password
		}, { headers: headers })
		.map(res => res.json());
	}

	logout() {
		this.authToken = null;
		this.user = null;
		localStorage.removeItem('id_token');
		localStorage.removeItem('user');
	}

	register(name, email, username, password) {
		let headers = new Headers();
		headers.append('Content-Type', 'application/json');
		return this.http.post(AppSettings.API_PATH + '/users/register', {
				name: name,
				email: email,
				username: username,
				password: password,
				isAdmin: false
			}, { headers: headers })
			.map(res => res.json());
		
	}

	updateUser(id, body) {
		let headers = new Headers();
		this.loadToken();
		headers.append('Authorization', this.authToken); 
		headers.append('Content-type', 'application/json');

		return this.http.put(AppSettings.API_PATH + '/users/' + id + '/update', body, { headers: headers })
		.map(res => res);
	}

	deleteUser(id) {
		let headers = new Headers();
		this.loadToken();
		headers.append('Authorization', this.authToken); 
		headers.append('Content-type', 'application/json');

		return this.http.delete(AppSettings.API_PATH + '/users/' + id + '/delete', { headers: headers })
		.map(res => res);
		
	}

	loadToken() {
		const token = localStorage.getItem('id_token');
		this.authToken = token;
	}

	loggedIn() {
		return tokenNotExpired('id_token', this.authToken);
	}

	storeUserData(token, user) {
		localStorage.setItem('id_token', token);
		localStorage.setItem('user', JSON.stringify(user));
		this.isAdminLogged = user.isAdmin;
		this.authToken = token;
		this.user = user;
	}

	getProfile() {
		let headers = new Headers();
		this.loadToken();
		headers.append('Authorization', this.authToken);
		headers.append('Content-type', 'application/json');

		return this.http.get(AppSettings.API_PATH + '/users/profile',{ headers: headers })
			.map(res => res.json());
		
	}

	getAllUsers() {
		let headers = new Headers();
		this.loadToken();
		headers.append('Authorization', this.authToken); 
		headers.append('Content-type', 'application/json');

		return this.http.get(AppSettings.API_PATH + '/users/all', { headers: headers })
			.map(res => res.json());

	}

	getUser(id) {
		let headers = new Headers();
		this.loadToken();
		headers.append('Authorization', this.authToken); 
		headers.append('Content-type', 'application/json');

		return this.http.get(AppSettings.API_PATH + '/users/' + id, { headers: headers })
			.map(res => res.json());

	}

}

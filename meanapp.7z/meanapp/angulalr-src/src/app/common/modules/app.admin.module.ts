import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { AdminComponent } from '../../pages/admin/admin.component';
import { UsersComponent } from '../../pages/admin/users/users.component';
import { EditUserComponent } from '../../pages/admin/edit-user/edit-user.component';
import { AppRoutingModule } from '../../common/modules/app.routing.module';

@NgModule({
    declarations: [
        AdminComponent,
        UsersComponent,
        EditUserComponent
    ],
    imports: [
        AppRoutingModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,    
    ],
    exports: [
        
    ],
    providers: []
})
export class AppAdminModule { }
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ApiService } from '../../common/services/api.service';
import { Router } from '@angular/router';

@Component({
	selector: 'app-register',
	templateUrl: './register.component.html',
	styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

	name: String;
	email: String;
	username: String;
	password: String;

	constructor(private router: Router, private apiService: ApiService) { }

	ngOnInit() {
	}

	register() {
		this.apiService.register(this.name, this.email, this.username, this.password).subscribe(data => {
			if (data.success) {
				//this.apiService.storeUserData(data.token, data.user);
				this.router.navigate(['/profile']);
			} else {
				console.log('noo')
			}
		})
	}

}

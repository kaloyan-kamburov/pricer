import component from './component';

import './main.less';

document.body.appendChild(component());
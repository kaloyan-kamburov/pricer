
const commonConfig = require('./config/webpack.common');
const productionConfig = require('./config/webpack.production');
const developmentConfig = require('./config/webpack.development');
const merge = require('webpack-merge');

module.exports = (env) => {
    if (env === 'production') {
        return merge(commonConfig, productionConfig);
    }

    return merge(commonConfig, developmentConfig);
};
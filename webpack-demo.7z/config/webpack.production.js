const merge = require('webpack-merge');

const productionConfig = merge([
]);

module.exports = productionConfig;
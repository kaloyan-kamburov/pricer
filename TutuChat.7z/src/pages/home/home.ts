import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { ApiService } from '../../common/services/api.service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public a;
  constructor(public navCtrl: NavController, private apiService: ApiService) {
    // this.a = this.apiService.login();
  }

}

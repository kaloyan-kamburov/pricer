import { Injectable } from '@angular/core';

import {  } from 'angularfire2';

@Injectable()
export class ApiService {
    constructor() {}

    
}